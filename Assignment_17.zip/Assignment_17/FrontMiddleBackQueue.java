import java.util.Deque;
import java.util.LinkedList;

class FrontMiddleBackQueue {
    Deque<Integer> front;
    Deque<Integer> back;

    public FrontMiddleBackQueue() {
        front = new LinkedList<>();
        back = new LinkedList<>();
    }

    public void pushFront(int val) {
        front.offerFirst(val);
        balance();
    }

    public void pushMiddle(int val) {
        if (front.size() > back.size()) {
            back.offerFirst(front.pollLast());
        }
        front.offerLast(val);
    }

    public void pushBack(int val) {
        back.offerLast(val);
        balance();
    }

    public int popFront() {
        if (!front.isEmpty()) {
            return front.pollFirst();
        } else if (!back.isEmpty()) {
            return back.pollFirst();
        } else {
            return -1;
        }
    }

    public int popMiddle() {
        if (!front.isEmpty()) {
            return front.pollLast();
        } else {
            return -1;
        }
    }

    public int popBack() {
        if (!back.isEmpty()) {
            return back.pollLast();
        } else if (!front.isEmpty()) {
            return front.pollLast();
        } else {
            return -1;
        }
    }

    private void balance() {
        if (front.size() > back.size() + 1) {
            back.offerFirst(front.pollLast());
        } else if (front.size() < back.size()) {
            front.offerLast(back.pollFirst());
        }
    }
}
