public class MaximumCircularSubarraySum {
    public static int maxSubarraySumCircular(int[] nums) {
        int n = nums.length;
        
        // Case 1: Maximum subarray sum using Kadane's algorithm
        int maxSum = kadane(nums);
        
        // Case 2: Maximum subarray sum with circular array
        int totalSum = 0;
        for (int i = 0; i < n; i++) {
            totalSum += nums[i];
            nums[i] = -nums[i]; // Negate the array elements for finding the minimum subarray sum
        }
        
        int minSum = kadane(nums); // Minimum subarray sum using Kadane's algorithm on negated array
        
        int circularMaxSum = totalSum + minSum; // Maximum sum with circular array
        
        // Return the maximum of the two cases
        return Math.max(maxSum, circularMaxSum);
    }
    
    private static int kadane(int[] nums) {
        int maxSum = nums[0];
        int currSum = nums[0];
        
        for (int i = 1; i < nums.length; i++) {
            currSum = Math.max(nums[i], currSum + nums[i]);
            maxSum = Math.max(maxSum, currSum);
        }
        
        return maxSum;
    }
    
    public static void main(String[] args) {
        int[] nums = {1, -2, 3, -2};
        int maxSum = maxSubarraySumCircular(nums);
        System.out.println(maxSum);
    }
}
