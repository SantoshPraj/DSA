class ListNode {
    int val;
    ListNode next;

    ListNode(int val) {
        this.val = val;
    }
}

public class FriendGame {
    public int findWinner(int n, int k) {
        ListNode head = buildCircularLinkedList(n);
        while (head.next != head) {
            for (int i = 1; i < k; i++) {
                head = head.next;
            }
            head.next = head.next.next;
        }
        return head.val;
    }

    private ListNode buildCircularLinkedList(int n) {
        ListNode head = new ListNode(1);
        ListNode curr = head;
        for (int i = 2; i <= n; i++) {
            curr.next = new ListNode(i);
            curr = curr.next;
        }
        curr.next = head;
        return head;
    }

    public static void main(String[] args) {
        FriendGame game = new FriendGame();
        System.out.println(game.findWinner(5, 2)); // Output: 3
    }
}
