import java.util.*;

public class CafeteriaProblem {
    public static int countStudents(int[] students, int[] sandwiches) {
        Queue<Integer> studentQueue = new LinkedList<>();
        Stack<Integer> sandwichStack = new Stack<>();

        // Initialize the student queue and sandwich stack
        for (int student : students) {
            studentQueue.offer(student);
        }
        for (int sandwich : sandwiches) {
            sandwichStack.push(sandwich);
        }

        int unableToEat = 0;
        int prevSize;

        // Simulate students taking sandwiches until no changes occur
        do {
            prevSize = studentQueue.size();

            // Check if the front student can take the top sandwich
            if (studentQueue.peek() == sandwichStack.peek()) {
                studentQueue.poll();
                sandwichStack.pop();
            } else {
                // Move the front student to the end of the queue
                studentQueue.offer(studentQueue.poll());
            }

            // Count the number of students unable to eat
            if (prevSize == studentQueue.size()) {
                unableToEat++;
            }
        } while (prevSize != studentQueue.size());

        return unableToEat;
    }

    public static void main(String[] args) {
        int[] students = {1, 1, 0, 0};
        int[] sandwiches = {0, 1, 0, 1};
        int unableToEat = countStudents(students, sandwiches);
        System.out.println(unableToEat);
    }
}
