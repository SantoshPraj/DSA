public class ReverseKNodes {
    static class Node {
        int data;
        Node next;

        Node(int data) {
            this.data = data;
            next = null;
        }
    }

    public static Node reverseKNodes(Node head, int k) {
        if (head == null || k <= 1) {
            return head; // Empty list or invalid k value, no reversal needed
        }

        Node current = head;
        Node previous = null;
        Node next = null;

        int count = 0;

        // Reverse the first k nodes
        while (current != null && count < k) {
            next = current.next;
            current.next = previous;
            previous = current;
            current = next;
            count++;
        }

        // Recursively reverse the remaining nodes
        if (next != null) {
            head.next = reverseKNodes(next, k);
        }

        return previous;
    }

    public static void printList(Node head) {
        Node current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }

    public static void main(String[] args) {
        Node head = new Node(1);
        head.next = new Node(2);
        head.next.next = new Node(2);
        head.next.next.next = new Node(4);
        head.next.next.next.next = new Node(5);
        head.next.next.next.next.next = new Node(6);
        head.next.next.next.next.next.next = new Node(7);
        head.next.next.next.next.next.next.next = new Node(8);

        int k = 4;

        Node newHead = reverseKNodes(head, k);
        printList(newHead);
    }
}
