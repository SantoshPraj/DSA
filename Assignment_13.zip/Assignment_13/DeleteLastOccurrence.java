public class DeleteLastOccurrence {
    static class Node {
        int data;
        Node next;

        Node(int data) {
            this.data = data;
            next = null;
        }
    }

    public static Node deleteLastOccurrence(Node head, int key) {
        if (head == null) {
            return null; // Empty list
        }

        Node prev = null;
        Node last = null;
        Node current = head;

        // Find the last occurrence of the key
        while (current != null) {
            if (current.data == key) {
                last = prev;
            }
            prev = current;
            current = current.next;
        }

        // If the last occurrence is found, delete it
        if (last != null) {
            if (last == head && head.data == key) {
                head = head.next; // Key found at the head, update the head
            } else {
                last.next = last.next.next; // Update the next reference of the node before the last occurrence
            }
        }

        return head;
    }

    public static void printList(Node head) {
        Node current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }

    public static void main(String[] args) {
        Node head = new Node(1);
        head.next = new Node(2);
        head.next.next = new Node(3);
        head.next.next.next = new Node(5);
        head.next.next.next.next = new Node(2);
        head.next.next.next.next.next = new Node(10);

        int key = 2;

        Node newHead = deleteLastOccurrence(head, key);
        printList(newHead);
    }
}
