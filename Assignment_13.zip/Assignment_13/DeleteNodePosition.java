public class DeleteNodePosition {
    static class Node {
        int data;
        Node prev;
        Node next;

        Node(int data) {
            this.data = data;
            prev = null;
            next = null;
        }
    }

    public static Node deleteNode(Node head, int position) {
        if (head == null)
            return null; // Empty list

        if (position == 1) {
            head = head.next; // Deleting the head node, update the head
            if (head != null)
                head.prev = null; // Update the prev reference of the new head
            return head;
        }

        Node current = head;
        int count = 1;

        // Traverse to the node at the given position
        while (count < position && current != null) {
            current = current.next;
            count++;
        }

        if (current == null)
            return head; // Node not found, return the original list

        if (current.next != null)
            current.next.prev = current.prev; // Update the prev reference of the next node
        if (current.prev != null)
            current.prev.next = current.next; // Update the next reference of the previous node

        return head;
    }

    public static void printList(Node head) {
        Node current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }

    public static void main(String[] args) {
        Node head = new Node(1);
        head.next = new Node(3);
        head.next.prev = head;
        head.next.next = new Node(4);
        head.next.next.prev = head.next;

        int position = 3;

        Node newHead = deleteNode(head, position);
        printList(newHead);
    }
}
