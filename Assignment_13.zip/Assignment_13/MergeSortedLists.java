public class MergeSortedLists {
    static class Node {
        int data;
        Node next;

        Node(int data) {
            this.data = data;
            next = null;
        }
    }

    public static Node mergeLists(Node headA, Node headB) {
        if (headA == null)
            return headB;
        if (headB == null)
            return headA;

        Node dummy = new Node(-1); // Dummy node to simplify the merging process
        Node current = dummy;

        while (headA != null && headB != null) {
            if (headA.data <= headB.data) {
                current.next = headA;
                headA = headA.next;
            } else {
                current.next = headB;
                headB = headB.next;
            }
            current = current.next;
        }

        // Append the remaining nodes of list A or list B
        if (headA != null)
            current.next = headA;
        if (headB != null)
            current.next = headB;

        return dummy.next; // Return the head of the merged list
    }

    public static void printList(Node head) {
        Node current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }

    public static void main(String[] args) {
        Node headA = new Node(5);
        headA.next = new Node(10);
        headA.next.next = new Node(15);

        Node headB = new Node(2);
        headB.next = new Node(3);
        headB.next.next = new Node(20);

        Node mergedHead = mergeLists(headA, headB);
        printList(mergedHead);
    }
}
