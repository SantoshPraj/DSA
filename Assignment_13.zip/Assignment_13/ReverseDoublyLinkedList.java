public class ReverseDoublyLinkedList {
    static class Node {
        int data;
        Node prev;
        Node next;

        Node(int data) {
            this.data = data;
            prev = null;
            next = null;
        }
    }

    public static Node reverse(Node head) {
        if (head == null || head.next == null) {
            return head; // Empty list or single-node list, no reversal needed
        }

        Node current = head;
        Node temp = null;

        // Swap prev and next pointers of each node
        while (current != null) {
            temp = current.prev;
            current.prev = current.next;
            current.next = temp;
            current = current.prev; // Move to the next node in the original next pointer
        }

        // Update the head pointer
        head = temp.prev;

        return head;
    }

    public static void printList(Node head) {
        Node current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }

    public static void main(String[] args) {
        Node head = new Node(10);
        head.next = new Node(8);
        head.next.prev = head;
        head.next.next = new Node(4);
        head.next.next.prev = head.next;
        head.next.next.next = new Node(2);
        head.next.next.next.prev = head.next.next;

        Node newHead = reverse(head);
        printList(newHead);
    }
}
