public class CreateNewList {
    static class Node {
        int data;
        Node next;

        Node(int data) {
            this.data = data;
            next = null;
        }
    }

    public static Node createNewList(Node head1, Node head2) {
        if (head1 == null || head2 == null) {
            return null; // Empty list(s), cannot create a new list
        }

        Node current1 = head1;
        Node current2 = head2;

        Node newHead = null;
        Node newTail = null;

        while (current1 != null && current2 != null) {
            int value;

            if (current1.data > current2.data) {
                value = current1.data;
                current1 = current1.next;
            } else {
                value = current2.data;
                current2 = current2.next;
            }

            Node newNode = new Node(value);

            if (newHead == null) {
                newHead = newNode;
                newTail = newNode;
            } else {
                newTail.next = newNode;
                newTail = newTail.next;
            }
        }

        // Append the remaining nodes from list1, if any
        while (current1 != null) {
            Node newNode = new Node(current1.data);
            newTail.next = newNode;
            newTail = newTail.next;
            current1 = current1.next;
        }

        // Append the remaining nodes from list2, if any
        while (current2 != null) {
            Node newNode = new Node(current2.data);
            newTail.next = newNode;
            newTail = newTail.next;
            current2 = current2.next;
        }

        return newHead;
    }

    public static void printList(Node head) {
        Node current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }

    public static void main(String[] args) {
        Node head1 = new Node(5);
        head1.next = new Node(2);
        head1.next.next = new Node(3);
        head1.next.next.next = new Node(8);

        Node head2 = new Node(1);
        head2.next = new Node(7);
        head2.next.next = new Node(4);
        head2.next.next.next = new Node(5);

        Node newHead = createNewList(head1, head2);
        printList(newHead);

        Node head3 = new Node(2);
        head3.next = new Node(8);
        head3.next.next = new Node(9);
        head3.next.next.next = new Node(3);

        Node head4 = new Node(5);
        head4.next = new Node(3);
        head4.next.next = new Node(6);
        head4.next.next.next = new Node(4);

        Node newHead2 = createNewList(head3, head4);
        printList(newHead2);
    }
}
