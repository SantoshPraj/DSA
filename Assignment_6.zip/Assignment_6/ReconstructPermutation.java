import java.util.ArrayList;
import java.util.List;

public class ReconstructPermutation {
    public static int[] findPermutation(String s) {
        int n = s.length();
        int[] permutation = new int[n + 1];
        List<Integer> indices = new ArrayList<>();

        for (int i = 0; i <= n; i++) {
            indices.add(i + 1);
        }

        int index = 0;
        for (int i = 0; i < n; i++) {
            if (s.charAt(i) == 'I') {
                permutation[i] = indices.get(index++);
            } else {
                permutation[i] = indices.get(indices.size() - 1);
                indices.remove(indices.size() - 1);
            }
        }

        permutation[n] = indices.get(0);

        return permutation;
    }

    public static void main(String[] args) {
        String s = "IDID";
        int[] permutation = findPermutation(s);

        System.out.println("Permutation: " + java.util.Arrays.toString(permutation));
    }
}
