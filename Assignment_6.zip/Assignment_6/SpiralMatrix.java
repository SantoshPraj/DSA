public class SpiralMatrix {
    public static int[][] generateMatrix(int n) {
        int[][] matrix = new int[n][n];

        int num = 1; // Current number to fill in the matrix
        int topRow = 0, bottomRow = n - 1; // Boundaries for rows
        int leftCol = 0, rightCol = n - 1; // Boundaries for columns

        while (num <= n * n) {
            // Fill the top row from left to right
            for (int i = leftCol; i <= rightCol; i++) {
                matrix[topRow][i] = num++;
            }
            topRow++;

            // Fill the right column from top to bottom
            for (int i = topRow; i <= bottomRow; i++) {
                matrix[i][rightCol] = num++;
            }
            rightCol--;

            // Fill the bottom row from right to left
            for (int i = rightCol; i >= leftCol; i--) {
                matrix[bottomRow][i] = num++;
            }
            bottomRow--;

            // Fill the left column from bottom to top
            for (int i = bottomRow; i >= topRow; i--) {
                matrix[i][leftCol] = num++;
            }
            leftCol++;
        }

        return matrix;
    }

    public static void main(String[] args) {
        int n = 3;
        int[][] matrix = generateMatrix(n);

        System.out.println("Spiral Matrix:");
        for (int[] row : matrix) {
            System.out.println(java.util.Arrays.toString(row));
        }
    }
}
