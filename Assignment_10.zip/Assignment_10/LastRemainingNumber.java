public class LastRemainingNumber {
    public static int lastRemaining(int n) {
        return removeNumbers(n, true);
    }

    private static int removeNumbers(int n, boolean isLeftToRight) {
        if (n == 1)
            return 1;

        if (isLeftToRight) {
            return 2 * removeNumbers(n / 2, false);
        } else {
            if (n % 2 == 1) {
                return 2 * removeNumbers(n / 2, true);
            } else {
                return 2 * removeNumbers(n / 2, true) - 1;
            }
        }
    }

    public static void main(String[] args) {
        int n = 9;
        int result = lastRemaining(n);
        System.out.println(result);
    }
}
