public class StringLengthCalculator {
    public static int calculateLength(String str) {
        return calculateLengthHelper(str, 0);
    }

    private static int calculateLengthHelper(String str, int index) {
        if (index == str.length()) {
            return 0;
        } else {
            return 1 + calculateLengthHelper(str, index + 1);
        }
    }

    public static void main(String[] args) {
        String str = "GEEKSFORGEEKS";
        int length = calculateLength(str);
        System.out.println(length);
    }
}
