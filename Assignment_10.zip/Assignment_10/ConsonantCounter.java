public class ConsonantCounter {
    public static int countConsonants(String str) {
        int count = 0;
        str = str.toLowerCase(); // Convert the string to lowercase for case-insensitive matching

        for (int i = 0; i < str.length(); i++) {
            char ch = str.charAt(i);
            if (isConsonant(ch)) {
                count++;
            }
        }

        return count;
    }

    private static boolean isConsonant(char ch) {
        return (ch >= 'a' && ch <= 'z') && !isVowel(ch);
    }

    private static boolean isVowel(char ch) {
        return ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u';
    }

    public static void main(String[] args) {
        String str1 = "abc de";
        int count1 = countConsonants(str1);
        System.out.println(count1);

        String str2 = "geeksforgeeks portal";
        int count2 = countConsonants(str2);
        System.out.println(count2);
    }
}
