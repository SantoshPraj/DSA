public class ContiguousSubstringCounter {
    public static int countContiguousSubstrings(String s) {
        return countContiguousSubstringsHelper(s, 0, s.length() - 1);
    }

    private static int countContiguousSubstringsHelper(String s, int start, int end) {
        if (start == end) {
            return 1;
        }

        int count = 0;

        if (s.charAt(start) == s.charAt(end)) {
            count += 1; // Count the substring starting and ending with the same character

            if (start + 1 <= end - 1) {
                count += countContiguousSubstringsHelper(s, start + 1, end - 1);
            }
        }

        count += countContiguousSubstringsHelper(s, start + 1, end); // Move to the next start index
        count += countContiguousSubstringsHelper(s, start, end - 1); // Move to the previous end index

        return count;
    }

    public static void main(String[] args) {
        String s1 = "abcab";
        int count1 = countContiguousSubstrings(s1);
        System.out.println(count1);

        String s2 = "aba";
        int count2 = countContiguousSubstrings(s2);
        System.out.println(count2);
    }
}
