public class SubsetPrinter {
    public static void printSubsets(String set) {
        printSubsetsHelper(set, 0, "");
    }

    private static void printSubsetsHelper(String set, int index, String currentSubset) {
        if (index == set.length()) {
            System.out.print(currentSubset + " ");
            return;
        }

        // Exclude the current element
        printSubsetsHelper(set, index + 1, currentSubset);

        // Include the current element
        printSubsetsHelper(set, index + 1, currentSubset + set.charAt(index));
    }

    public static void main(String[] args) {
        String set = "abc";
        printSubsets(set);
    }
}
