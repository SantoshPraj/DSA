public class PowerOfThreeee {
    public static boolean isPowerOfThree(int n) {
        if (n <= 0 || n % 3 != 0)
            return false;
        if (n == 1)
            return true;
        return isPowerOfThree(n / 3);
    }

    public static void main(String[] args) {
        int n = -1;
        boolean result = isPowerOfThree(n);
        System.out.println(result);
    }
}
