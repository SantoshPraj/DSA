public class LastRemainingNumberr {
    public static int lastRemaining(int n) {
        return removeNumbers(n, true);
    }

    private static int removeNumbers(int n, boolean isLeftToRight) {
        return n;
    }

    public static void main(String[] args) {
        int n = 1;
        int result = lastRemaining(n);
        System.out.println(result);
    }
}
