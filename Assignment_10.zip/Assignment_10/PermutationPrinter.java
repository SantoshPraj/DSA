public class PermutationPrinter {
    public static void printPermutations(String str) {
        printPermutationsHelper(str, 0, str.length() - 1);
    }

    private static void printPermutationsHelper(String str, int left, int right) {
        if (left == right) {
            System.out.print(str + " ");
            return;
        }

        for (int i = left; i <= right; i++) {
            str = swap(str, left, i); // Swap characters
            printPermutationsHelper(str, left + 1, right); // Recurse for the remaining string
            str = swap(str, left, i); // Restore the original string
        }
    }

    private static String swap(String str, int i, int j) {
        char[] charArray = str.toCharArray();
        char temp = charArray[i];
        charArray[i] = charArray[j];
        charArray[j] = temp;
        return String.valueOf(charArray);
    }

    public static void main(String[] args) {
        String str1 = "cd";
        printPermutations(str1);

        System.out.println();

        String str2 = "abb";
        printPermutations(str2);
    }
}
