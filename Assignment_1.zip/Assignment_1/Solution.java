import java.util.HashSet;

public class Solution {
    public static boolean containsDuplicate(int[] nums) {
        HashSet<Integer> set = new HashSet<>();
        for (int num : nums) {
            // If the element already exists in the set, it's a duplicate
            if (set.contains(num)) {
                return true;
            } else {
                // Add the element to the set
                set.add(num);
            }
        }
        // No duplicates found
        return false;
    }

    public static void main(String[] args) {
        int[] nums = {1, 2, 3, 1};
        System.out.println(containsDuplicate(nums)); // Output: true
    }
}
