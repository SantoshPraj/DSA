public class Move {
    public static void main(String[] args) {
        int[] nums = {0, 1, 0, 3, 12};
        moveZeroes(nums);
        
        // Print the modified array
        for (int num : nums) {
            System.out.print(num + " ");
        }
    }

    public static void moveZeroes(int[] nums) {
        int index = 0; // index to track the position of the next non-zero element

        // Traverse the array
        for (int num : nums) {
            if (num != 0) {
                nums[index++] = num; // Move non-zero element to the front
            }
        }

        // Fill the remaining elements with zeros
        while (index < nums.length) {
            nums[index++] = 0;
        }
    }
}
