import java.util.HashSet;

public class Duplicate {
    public static void main(String[] args) {
        int[] nums = {1, 2, 3, 1};
        boolean hasDuplicates = containsDuplicate(nums);

        // Print the result
        System.out.println(hasDuplicates);
    }

    public static boolean containsDuplicate(int[] nums) {
        HashSet<Integer> set = new HashSet<>();

        // Iterate through the array
        for (int num : nums) {
            // If the set already contains the number, it's a duplicate
            if (set.contains(num)) {
                return true;
            }
            // Otherwise, add the number to the set
            set.add(num);
        }

        // No duplicates found
        return false;
    }
}
