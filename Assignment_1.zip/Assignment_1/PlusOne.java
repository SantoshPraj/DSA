public class PlusOne {
    public static int[] plusOne(int[] digits) {
        int n = digits.length;
        
        // Iterate from the least significant digit
        for (int i = n - 1; i >= 0; i--) {
            if (digits[i] < 9) {
                digits[i]++; // Increment the digit
                return digits;
            } else {
                digits[i] = 0; // Set the digit to 0
            }
        }
        
        // If all digits were 9, create a new array with one additional digit
        int[] newDigits = new int[n + 1];
        newDigits[0] = 1; // Set the most significant digit to 1
        
        return newDigits;
    }

    public static void main(String[] args) {
        int[] digits = {1, 2, 3};
        int[] result = plusOne(digits);

        System.out.println("Output: " + Arrays.toString(result));
    }
}
