import java.util.Arrays;

public class Count {
    public static void main(String[] args) {
        int[] nums = {1, 2, 2, 4};
        int[] result = findErrorNums(nums);
        
        // Print the result
        System.out.println(Arrays.toString(result));
    }

    public static int[] findErrorNums(int[] nums) {
        int[] result = new int[2];
        int[] count = new int[nums.length];

        // Count the occurrences of each number
        for (int num : nums) {
            count[num - 1]++;
        }

        // Find the number that occurs twice
        for (int i = 0; i < count.length; i++) {
            if (count[i] == 2) {
                result[0] = i + 1;
                break;
            }
        }

        // Find the missing number
        for (int i = 0; i < count.length; i++) {
            if (count[i] == 0) {
                result[1] = i + 1;
                break;
            }
        }

        return result;
    }
}
