import java.util.Arrays;

public class Meeting {
    public static void main(String[] args) {
        int[][] intervals = {{0, 30}, {5, 10}, {15, 20}};
        boolean canAttendAllMeetings = canAttendMeetings(intervals);

        // Print whether the person can attend all meetings
        System.out.println(canAttendAllMeetings);
    }

    public static boolean canAttendMeetings(int[][] intervals) {
        // Sort the intervals based on their start time
        Arrays.sort(intervals, (a, b) -> a[0] - b[0]);

        // Check for overlaps in the intervals
        for (int i = 1; i < intervals.length; i++) {
            if (intervals[i][0] < intervals[i - 1][1]) {
                return false; // Overlap found, person cannot attend all meetings
            }
        }

        return true; // No overlaps found, person can attend all meetings
    }
}
