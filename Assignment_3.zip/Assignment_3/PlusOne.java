import java.util.Arrays;

public class PlusOne {
    public static void main(String[] args) {
        int[] digits = {1, 2, 3};
        int[] result = plusOne(digits);

        // Print the resulting array after incrementing
        System.out.println(Arrays.toString(result));
    }

    public static int[] plusOne(int[] digits) {
        int n = digits.length;

        // Start from the least significant digit
        for (int i = n - 1; i >= 0; i--) {
            if (digits[i] < 9) {
                digits[i]++; // Increment the digit
                return digits; // No carryover, return the updated array
            } else {
                digits[i] = 0; // Set the digit to 0
            }
        }

        // If all digits were 9, a new leading digit of 1 is needed
        int[] result = new int[n + 1];
        result[0] = 1;

        return result;
    }
}
