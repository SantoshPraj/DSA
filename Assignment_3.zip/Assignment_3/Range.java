import java.util.ArrayList;
import java.util.List;

public class Range {
    public static void main(String[] args) {
        int[] nums = {0, 1, 3, 50, 75};
        int lower = 0;
        int upper = 99;
        List<List<Integer>> missingRanges = findMissingRanges(nums, lower, upper);

        // Print the missing ranges
        for (List<Integer> range : missingRanges) {
            System.out.println(range);
        }
    }

    public static List<List<Integer>> findMissingRanges(int[] nums, int lower, int upper) {
        List<List<Integer>> missingRanges = new ArrayList<>();
        int n = nums.length;

        // Handle the lower bound if necessary
        if (nums.length == 0 || nums[0] > lower) {
            addRange(missingRanges, lower, nums[0] - 1);
        }

        // Iterate through the array and find missing ranges
        for (int i = 1; i < n; i++) {
            if (nums[i] - nums[i - 1] > 1) {
                addRange(missingRanges, nums[i - 1] + 1, nums[i] - 1);
            }
        }

        // Handle the upper bound if necessary
        if (nums.length == 0 || nums[n - 1] < upper) {
            addRange(missingRanges, nums[n - 1] + 1, upper);
        }

        return missingRanges;
    }

    private static void addRange(List<List<Integer>> missingRanges, int start, int end) {
        if (start > end) {
            return; // Invalid range, do not add
        }

        List<Integer> range = new ArrayList<>();
        range.add(start);
        range.add(end);
        missingRanges.add(range);
    }
}
