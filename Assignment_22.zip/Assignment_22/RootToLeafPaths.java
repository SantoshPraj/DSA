import java.util.Stack;

class TreeNode {
    int val;
    TreeNode left;
    TreeNode right;

    TreeNode(int val) {
        this.val = val;
    }
}

public class RootToLeafPaths {
    public void printRootToLeafPaths(TreeNode root) {
        if (root == null) {
            return;
        }

        Stack<TreeNode> stack = new Stack<>();
        Stack<String> pathStack = new Stack<>();
        stack.push(root);
        pathStack.push(Integer.toString(root.val));

        while (!stack.isEmpty()) {
            TreeNode curr = stack.pop();
            String path = pathStack.pop();

            if (curr.left == null && curr.right == null) {
                System.out.println(path);
            }

            if (curr.right != null) {
                stack.push(curr.right);
                pathStack.push(path + "->" + curr.right.val);
            }

            if (curr.left != null) {
                stack.push(curr.left);
                pathStack.push(path + "->" + curr.left.val);
            }
        }
    }

    public static void main(String[] args) {
        RootToLeafPaths pathPrinter = new RootToLeafPaths();

        TreeNode root = new TreeNode(6);
        root.left = new TreeNode(3);
        root.right = new TreeNode(5);
        root.left.left = new TreeNode(2);
        root.left.right = new TreeNode(5);
        root.right.right = new TreeNode(4);
        root.left.right.left = new TreeNode(7);
        root.left.right.right = new TreeNode(4);

        pathPrinter.printRootToLeafPaths(root);
    }
}
