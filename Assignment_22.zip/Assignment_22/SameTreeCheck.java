class TreeNode {
    int val;
    TreeNode left;
    TreeNode right;

    TreeNode(int val) {
        this.val = val;
    }
}

public class SameTreeCheck {
    int preIndex = 0;

    public TreeNode buildTree(int[] inorder, int[] postorder, int inStart, int inEnd) {
        if (inStart > inEnd) {
            return null;
        }

        TreeNode root = new TreeNode(postorder[preIndex--]);

        if (inStart == inEnd) {
            return root;
        }

        int inIndex = search(inorder, inStart, inEnd, root.val);

        root.right = buildTree(inorder, postorder, inIndex + 1, inEnd);
        root.left = buildTree(inorder, postorder, inStart, inIndex - 1);

        return root;
    }

    public int search(int[] inorder, int start, int end, int key) {
        for (int i = start; i <= end; i++) {
            if (inorder[i] == key) {
                return i;
            }
        }
        return -1;
    }

    public boolean isSameTree(int[] inorder, int[] preorder, int[] postorder) {
        preIndex = preorder.length - 1;
        TreeNode constructedTree = buildTree(inorder, postorder, 0, inorder.length - 1);

        return isSame(constructedTree, preorder, 0);
    }

    public boolean isSame(TreeNode root, int[] preorder, int index) {
        if (root == null) {
            return true;
        }

        if (root.val != preorder[index]) {
            return false;
        }

        boolean leftSame = isSame(root.left, preorder, index + 1);
        boolean rightSame = isSame(root.right, preorder, index + 1);

        return leftSame || rightSame;
    }

    public static void main(String[] args) {
        SameTreeCheck treeChecker = new SameTreeCheck();

        int[] inorder = { 4, 2, 5, 1, 3 };
        int[] preorder = { 1, 2, 4, 5, 3 };
        int[] postorder = { 4, 5, 2, 3, 1 };

        boolean isSameTree = treeChecker.isSameTree(inorder, preorder, postorder);

        System.out.println(isSameTree ? "Yes" : "No");
    }
}
