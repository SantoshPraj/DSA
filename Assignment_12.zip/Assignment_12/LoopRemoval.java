public class LoopRemoval {
    static class Node {
        int data;
        Node next;

        Node(int data) {
            this.data = data;
            next = null;
        }
    }

    public static void removeLoop(Node head) {
        if (head == null || head.next == null) {
            return; // Empty list or single-node list, no loop to remove
        }

        Node slow = head;
        Node fast = head;

        // Find the meeting point of the slow and fast pointers
        while (fast != null && fast.next != null) {
            slow = slow.next;
            fast = fast.next.next;

            if (slow == fast) {
                break; // Loop detected, exit the loop
            }
        }

        // No loop present, return
        if (slow != fast) {
            return;
        }

        // Move the slow pointer to the head and move both pointers one node at a time
        slow = head;
        while (slow.next != fast.next) {
            slow = slow.next;
            fast = fast.next;
        }

        // Set the next pointer of the last node to null to remove the loop
        fast.next = null;
    }

    public static void main(String[] args) {
        Node head = new Node(1);
        head.next = new Node(3);
        head.next.next = new Node(4);
        head.next.next.next = head.next;

        removeLoop(head);

        // Print the modified list
        Node current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
    }
}
