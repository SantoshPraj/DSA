public class RetainMDeleteN {
    static class Node {
        int data;
        Node next;

        Node(int data) {
            this.data = data;
            next = null;
        }
    }

    public static Node retainAndDelete(Node head, int M, int N) {
        if (head == null || M <= 0 || N <= 0) {
            return head; // Invalid input, return the original list
        }

        Node current = head;
        Node previous = null;

        int count;

        while (current != null) {
            // Retain M nodes
            for (count = 1; count < M && current != null; count++) {
                current = current.next;
            }

            if (current == null) {
                break;
            }

            // Delete N nodes
            Node nextStart = current.next;
            for (count = 1; count <= N && nextStart != null; count++) {
                Node temp = nextStart;
                nextStart = nextStart.next;
                temp.next = null; // Disconnect the deleted nodes
            }

            current.next = nextStart;
            current = nextStart;
        }

        return head;
    }

    public static void printList(Node head) {
        Node current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }

    public static void main(String[] args) {
        Node head1 = new Node(1);
        head1.next = new Node(2);
        head1.next.next = new Node(3);
        head1.next.next.next = new Node(4);
        head1.next.next.next.next = new Node(5);
        head1.next.next.next.next.next = new Node(6);
        head1.next.next.next.next.next.next = new Node(7);
        head1.next.next.next.next.next.next.next = new Node(8);

        int M1 = 2, N1 = 2;
        Node newHead1 = retainAndDelete(head1, M1, N1);
        printList(newHead1);

        Node head2 = new Node(1);
        head2.next = new Node(2);
        head2.next.next = new Node(3);
        head2.next.next.next = new Node(4);
        head2.next.next.next.next = new Node(5);
        head2.next.next.next.next.next = new Node(6);
        head2.next.next.next.next.next.next = new Node(7);
        head2.next.next.next.next.next.next.next = new Node(8);
        head2.next.next.next.next.next.next.next.next = new Node(9);
        head2.next.next.next.next.next.next.next.next.next = new Node(10);

        int M2 = 3, N2 = 2;
        Node newHead2 = retainAndDelete(head2, M2, N2);
        printList(newHead2);

        Node head3 = new Node(1);
        head3.next = new Node(2);
        head3.next.next = new Node(3);
        head3.next.next.next = new Node(4);
        head3.next.next.next.next = new Node(5);
        head3.next.next.next.next.next = new Node(6);
        head3.next.next.next.next.next.next = new Node(7);
        head3.next.next.next.next.next.next.next = new Node(8);
        head3.next.next.next.next.next.next.next.next = new Node(9);
        head3.next.next.next.next.next.next.next.next.next = new Node(10);

        int M3 = 1, N3 = 1;
        Node newHead3 = retainAndDelete(head3, M3, N3);
        printList(newHead3);
    }
}
