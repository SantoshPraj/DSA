public class PalindromeLinkedList {
    static class Node {
        char data;
        Node next;

        Node(char data) {
            this.data = data;
            next = null;
        }
    }

    public static boolean isPalindrome(Node head) {
        if (head == null || head.next == null) {
            return true; // Empty list or single-node list is considered a palindrome
        }

        Node slow = head;
        Node fast = head;

        // Move the fast pointer to the end and the slow pointer to the middle
        while (fast != null && fast.next != null) {
            slow = slow.next;
            fast = fast.next.next;
        }

        // Reverse the second half of the list
        slow = reverseList(slow);

        // Compare the first half with the reversed second half
        while (slow != null) {
            if (head.data != slow.data) {
                return false; // Characters don't match, not a palindrome
            }
            head = head.next;
            slow = slow.next;
        }

        return true; // All characters match, it is a palindrome
    }

    private static Node reverseList(Node head) {
        Node prev = null;
        Node current = head;
        Node next;

        while (current != null) {
            next = current.next;
            current.next = prev;
            prev = current;
            current = next;
        }

        return prev;
    }

    public static void main(String[] args) {
        Node head1 = new Node('R');
        head1.next = new Node('A');
        head1.next.next = new Node('D');
        head1.next.next.next = new Node('A');
        head1.next.next.next.next = new Node('R');

        boolean isPalindrome1 = isPalindrome(head1);
        System.out.println(isPalindrome1);

        Node head2 = new Node('C');
        head2.next = new Node('O');
        head2.next.next = new Node('D');
        head2.next.next.next = new Node('E');

        boolean isPalindrome2 = isPalindrome(head2);
        System.out.println(isPalindrome2);
    }
}
