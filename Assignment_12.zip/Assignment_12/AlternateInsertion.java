public class AlternateInsertion {
    static class Node {
        int data;
        Node next;

        Node(int data) {
            this.data = data;
            next = null;
        }
    }

    public static void alternateInsert(Node head1, Node head2) {
        if (head1 == null || head2 == null) {
            return; // Empty list(s), no nodes to insert
        }

        Node curr1 = head1;
        Node curr2 = head2;
        Node next1, next2;

        while (curr1 != null && curr2 != null) {
            next1 = curr1.next;
            next2 = curr2.next;

            curr1.next = curr2;
            curr2.next = next1;

            curr1 = next1;
            curr2 = next2;
        }

        // If there are remaining nodes in the second list,
        // append them to the end of the first list
        if (curr2 != null) {
            Node lastNode = getLastNode(head1);
            lastNode.next = curr2;
        }
    }

    public static Node getLastNode(Node head) {
        if (head == null) {
            return null;
        }

        Node current = head;
        while (current.next != null) {
            current = current.next;
        }
        return current;
    }

    public static void printList(Node head) {
        Node current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }

    public static void main(String[] args) {
        Node head1 = new Node(5);
        head1.next = new Node(7);
        head1.next.next = new Node(17);
        head1.next.next.next = new Node(13);
        head1.next.next.next.next = new Node(11);

        Node head2 = new Node(12);
        head2.next = new Node(10);
        head2.next.next = new Node(2);
        head2.next.next.next = new Node(4);
        head2.next.next.next.next = new Node(6);

        alternateInsert(head1, head2);

        System.out.println("First List:");
        printList(head1);

        System.out.println("Second List:");
        printList(head2);
    }
}
