public class NthNodeFromEnd {
    static class Node {
        int data;
        Node next;

        Node(int data) {
            this.data = data;
            next = null;
        }
    }

    public static int findNthFromEnd(Node head, int N) {
        if (head == null || N <= 0) {
            return -1; // Invalid input, return -1
        }

        Node slow = head;
        Node fast = head;

        // Move the fast pointer N nodes ahead
        for (int i = 0; i < N; i++) {
            if (fast == null) {
                return -1; // N is greater than the number of nodes in the list, return -1
            }
            fast = fast.next;
        }

        // Move both pointers until the fast pointer reaches the end
        while (fast != null) {
            slow = slow.next;
            fast = fast.next;
        }

        if (slow == null) {
            return -1; // N is greater than the number of nodes in the list, return -1
        }

        return slow.data;
    }

    public static void main(String[] args) {
        Node head = new Node(1);
        head.next = new Node(2);
        head.next.next = new Node(3);
        head.next.next.next = new Node(4);
        head.next.next.next.next = new Node(5);
        head.next.next.next.next.next = new Node(6);
        head.next.next.next.next.next.next = new Node(7);
        head.next.next.next.next.next.next.next = new Node(8);
        head.next.next.next.next.next.next.next.next = new Node(9);

        int N = 2;
        int nthNode = findNthFromEnd(head, N);
        System.out.println(nthNode);
    }
}
