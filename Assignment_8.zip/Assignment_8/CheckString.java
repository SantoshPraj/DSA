import java.util.Stack;

public class CheckString {
    public boolean checkValidString(String s) {
        Stack<Integer> stack = new Stack<>();

        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);

            if (c == '(' || c == '*') {
                stack.push(i);
            } else if (c == ')') {
                if (!stack.isEmpty()) {
                    stack.pop();
                } else {
                    return false;
                }
            }
        }

        while (!stack.isEmpty()) {
            int index = stack.pop();

            if (s.charAt(index) == '(') {
                boolean matched = false;

                while (!stack.isEmpty()) {
                    if (s.charAt(stack.pop()) == '*') {
                        matched = true;
                        break;
                    }
                }

                if (!matched) {
                    return false;
                }
            }
        }

        return true;
    }

    public static void main(String[] args) {
        Solution solution = new Solution();
        String s = "()";
        boolean result = solution.checkValidString(s);
        System.out.println(result); // Output: true
    }
}
