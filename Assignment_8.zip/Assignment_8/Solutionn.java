import java.util.*;

class TreeNode {
    int val;
    TreeNode left;
    TreeNode right;
    
    TreeNode(int val) {
        this.val = val;
    }
}

public class Solutionn {
    public TreeNode str2tree(String s) {
        if (s.isEmpty()) {
            return null;
        }
        
        return buildTree(s, 0, s.length() - 1);
    }
    
    private TreeNode buildTree(String s, int start, int end) {
        if (start > end) {
            return null;
        }
        
        int valEnd = start;
        while (valEnd <= end && Character.isDigit(s.charAt(valEnd))) {
            valEnd++;
        }
        
        int val = Integer.parseInt(s.substring(start, valEnd));
        TreeNode root = new TreeNode(val);
        
        if (valEnd <= end) {
            int openParenCount = 0;
            int closingIndex = valEnd;
            
            while (closingIndex <= end) {
                if (s.charAt(closingIndex) == '(') {
                    openParenCount++;
                } else if (s.charAt(closingIndex) == ')') {
                    openParenCount--;
                    
                    if (openParenCount == 0) {
                        break;
                    }
                }
                
                closingIndex++;
            }
            
            root.left = buildTree(s, valEnd + 1, closingIndex - 1);
            root.right = buildTree(s, closingIndex + 2, end - 1);
        }
        
        return root;
    }
    
    public static void main(String[] args) {
        Solution solution = new Solution();
        String s = "4(2(3)(1))(6(5))";
        TreeNode root = solution.str2tree(s);
        List<Integer> result = solution.inorderTraversal(root);
        System.out.println(result); // Output: [3, 2, 1, 4, 5, 6]
    }
    
    // Helper method for inorder traversal to validate the constructed tree
    private List<Integer> inorderTraversal(TreeNode root) {
        List<Integer> result = new ArrayList<>();
        if (root != null) {
            result.addAll(inorderTraversal(root.left));
            result.add(root.val);
            result.addAll(inorderTraversal(root.right));
        }
        return result;
    }
}
