public class Compress {
    public int compress(char[] chars) {
        int write = 0;
        int read = 0;
        int count = 1;

        for (read = 1; read <= chars.length; read++) {
            if (read < chars.length && chars[read] == chars[read - 1]) {
                count++;
            } else {
                chars[write++] = chars[read - 1];
                if (count > 1) {
                    String countStr = String.valueOf(count);
                    for (char c : countStr.toCharArray()) {
                        chars[write++] = c;
                    }
                }
                count = 1;
            }
        }

        return write;
    }

    public static void main(String[] args) {
        Compress solution = new Compress();
        char[] chars = {'a', 'a', 'b', 'b', 'c', 'c', 'c'};
        int result = solution.compress(chars);
        System.out.println(result); // Output: 6
        System.out.println(Arrays.toString(Arrays.copyOfRange(chars, 0, result))); // Output: [a, 2, b, 2, c, 3]
    }
}
