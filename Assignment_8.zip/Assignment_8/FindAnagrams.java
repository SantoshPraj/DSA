import java.util.*;

public class FindAnagrams {
    public List<Integer> findAnagrams(String s, String p) {
        List<Integer> result = new ArrayList<>();
        int[] pFreq = new int[26];
        int[] windowFreq = new int[26];
        
        for (char c : p.toCharArray()) {
            pFreq[c - 'a']++;
        }
        
        int left = 0;
        for (int right = 0; right < s.length(); right++) {
            char c = s.charAt(right);
            windowFreq[c - 'a']++;
            
            if (right - left + 1 == p.length()) {
                if (Arrays.equals(pFreq, windowFreq)) {
                    result.add(left);
                }
                
                windowFreq[s.charAt(left) - 'a']--;
                left++;
            }
        }
        
        return result;
    }
    
    public static void main(String[] args) {
        FindAnagrams solution = new FindAnagrams();
        String s = "cbaebabacd";
        String p = "abc";
        List<Integer> result = solution.findAnagrams(s, p);
        System.out.println(result); // Output: [0, 6]
    }
}
