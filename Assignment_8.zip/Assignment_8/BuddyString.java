import java.util.*;

public class BuddyString {
    public boolean buddyStrings(String s, String goal) {
        if (s.length() != goal.length()) {
            return false;
        }

        List<Integer> mismatchIndices = new ArrayList<>();
        List<Character> mismatchChars = new ArrayList<>();

        for (int i = 0; i < s.length(); i++) {
            if (s.charAt(i) != goal.charAt(i)) {
                mismatchIndices.add(i);
                mismatchChars.add(s.charAt(i));
            }
        }

        if (mismatchIndices.isEmpty()) {
            // If s and goal are already equal, check if we can swap two same characters in s
            Set<Character> seen = new HashSet<>();
            for (char c : s.toCharArray()) {
                if (seen.contains(c)) {
                    return true;
                }
                seen.add(c);
            }
            return false;
        } else if (mismatchIndices.size() == 2) {
            int index1 = mismatchIndices.get(0);
            int index2 = mismatchIndices.get(1);
            char char1 = mismatchChars.get(0);
            char char2 = mismatchChars.get(1);
            return s.charAt(index1) == char2 && s.charAt(index2) == char1;
        }

        return false;
    }

    public static void main(String[] args) {
        BuddyString solution = new BuddyString();
        String s = "ab";
        String goal = "ba";
        boolean result = solution.buddyStrings(s, goal);
        System.out.println(result); // Output: true
    }
}
