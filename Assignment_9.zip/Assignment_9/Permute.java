public class Permute {
    public void printPermutations(String S) {
        char[] chars = S.toCharArray();
        permute(0, chars);
    }

    private void permute(int index, char[] chars) {
        if (index == chars.length - 1) {
            System.out.println(new String(chars));
            return;
        }

        for (int i = index; i < chars.length; i++) {
            swap(chars, index, i);
            permute(index + 1, chars);
            swap(chars, index, i);
        }
    }

    private void swap(char[] chars, int i, int j) {
        char temp = chars[i];
        chars[i] = chars[j];
        chars[j] = temp;
    }

    public static void main(String[] args) {
        Permute solution = new Permute();
        String S1 = "ABC";
        String S2 = "XY";
        solution.printPermutations(S1);
        System.out.println("----");
        solution.printPermutations(S2);
    }
}
