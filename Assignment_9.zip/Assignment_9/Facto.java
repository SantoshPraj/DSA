public class Facto {
    public int factorial(int N) {
        if (N == 0 || N == 1) {
            return 1;
        }
        
        return N * factorial(N - 1);
    }

    public static void main(String[] args) {
        Facto solution = new Facto();
        int N1 = 5;
        int N2 = 4;
        int result1 = solution.factorial(N1);
        int result2 = solution.factorial(N2);
        System.out.println(result1); // Output: 120
        System.out.println(result2); // Output: 24
    }
}
