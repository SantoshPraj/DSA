public class PowerOfTwo {
    public boolean isPowerOfTwo(int n) {
        if (n <= 0) {
            return false;
        }
        
        if (n == 1) {
            return true;
        }
        
        if (n % 2 != 0) {
            return false;
        }
        
        return isPowerOfTwo(n / 2);
    }

    public static void main(String[] args) {
        PowerOfTwo solution = new PowerOfTwo();
        int n1 = 1;
        int n2 = 16;
        int n3 = 3;
        boolean result1 = solution.isPowerOfTwo(n1);
        boolean result2 = solution.isPowerOfTwo(n2);
        boolean result3 = solution.isPowerOfTwo(n3);
        System.out.println(result1); // Output: true
        System.out.println(result2); // Output: true
        System.out.println(result3); // Output: false
    }
}
