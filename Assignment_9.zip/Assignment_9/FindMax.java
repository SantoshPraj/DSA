public class FindMax {
    public int findMax(int[] arr) {
        return findMaxRecursive(arr, 0, arr.length - 1);
    }

    private int findMaxRecursive(int[] arr, int start, int end) {
        if (start == end) {
            return arr[start];
        }

        int mid = (start + end) / 2;
        int maxLeft = findMaxRecursive(arr, start, mid);
        int maxRight = findMaxRecursive(arr, mid + 1, end);

        return Math.max(maxLeft, maxRight);
    }

    public static void main(String[] args) {
        FindMax solution = new FindMax();
        int[] arr1 = {1, 4, 3, -5, -4, 8, 6};
        int[] arr2 = {1, 4, 45, 6, 10, -8};
        int result1 = solution.findMax(arr1);
        int result2 = solution.findMax(arr2);
        System.out.println(result1); // Output: 8
        System.out.println(result2); // Output: 45
    }
}
