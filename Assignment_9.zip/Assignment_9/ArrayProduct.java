public class ArrayProduct {
    public int arrayProduct(int[] arr) {
        return arrayProductRecursive(arr, 0, arr.length - 1);
    }

    private int arrayProductRecursive(int[] arr, int start, int end) {
        if (start == end) {
            return arr[start];
        }

        int mid = (start + end) / 2;
        int productLeft = arrayProductRecursive(arr, start, mid);
        int productRight = arrayProductRecursive(arr, mid + 1, end);

        return productLeft * productRight;
    }

    public static void main(String[] args) {
        ArrayProduct solution = new ArrayProduct();
        int[] arr1 = {1, 2, 3, 4, 5};
        int[] arr2 = {1, 6, 3};
        int result1 = solution.arrayProduct(arr1);
        int result2 = solution.arrayProduct(arr2);
        System.out.println(result1); // Output: 120
        System.out.println(result2); // Output: 18
    }
}
