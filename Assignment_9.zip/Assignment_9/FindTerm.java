public class FindTerm {
    public int findNthTerm(int a, int d, int N) {
        if (N == 1) {
            return a;
        }

        int prevTerm = findNthTerm(a, d, N - 1);
        return prevTerm + d;
    }

    public static void main(String[] args) {
        FindTerm solution = new FindTerm();
        int a1 = 2, d1 = 1, N1 = 5;
        int a2 = 5, d2 = 2, N2 = 10;
        int result1 = solution.findNthTerm(a1, d1, N1);
        int result2 = solution.findNthTerm(a2, d2, N2);
        System.out.println(result1); // Output: 6
        System.out.println(result2); // Output: 23
    }
}
