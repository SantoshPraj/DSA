public class Powers {
    public int power(int N, int P) {
        if (P == 0) {
            return 1;
        }
        
        if (P == 1) {
            return N;
        }
        
        int result = power(N, P / 2);
        
        if (P % 2 == 0) {
            return result * result;
        } else {
            return N * result * result;
        }
    }

    public static void main(String[] args) {
        Powers solution = new Powers();
        int N1 = 5;
        int P1 = 2;
        int N2 = 2;
        int P2 = 5;
        int result1 = solution.power(N1, P1);
        int result2 = solution.power(N2, P2);
        System.out.println(result1); // Output: 25
        System.out.println(result2); // Output: 32
    }
}
