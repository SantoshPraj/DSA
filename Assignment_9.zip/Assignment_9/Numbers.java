public class Numbers {
    public int sumOfFirstNNumbers(int n) {
        if (n <= 0) {
            return 0;
        }
        
        if (n == 1) {
            return 1;
        }
        
        return n + sumOfFirstNNumbers(n - 1);
    }

    public static void main(String[] args) {
        Numbers solution = new Numbers();
        int n1 = 3;
        int n2 = 5;
        int result1 = solution.sumOfFirstNNumbers(n1);
        int result2 = solution.sumOfFirstNNumbers(n2);
        System.out.println(result1); // Output: 6
        System.out.println(result2); // Output: 15
    }
}
