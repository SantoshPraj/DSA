import java.util.Arrays;

public class PairSum {
    public static void main(String[] args) {
        int[] nums = {1, 4, 3, 2};
        int maxSum = arrayPairSum(nums);
        
        // Print the maximum sum
        System.out.println(maxSum);
    }

    public static int arrayPairSum(int[] nums) {
        Arrays.sort(nums);

        int maxSum = 0;

        // Iterate over the sorted array, considering every second element
        for (int i = 0; i < nums.length; i += 2) {
            maxSum += nums[i]; // Add the minimum value of each pair to the sum
        }

        return maxSum;
    }
}
