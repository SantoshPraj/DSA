import java.util.HashSet;

public class Candy {
    public static void main(String[] args) {
        int[] candyType = {1, 1, 2, 2, 3, 3};
        int maxCandies = distributeCandies(candyType);
        
        // Print the maximum number of different types of candies Alice can eat
        System.out.println(maxCandies);
    }

    public static int distributeCandies(int[] candyType) {
        int maxCandies = candyType.length / 2;
        HashSet<Integer> uniqueCandies = new HashSet<>();

        // Count the number of unique candy types
        for (int candy : candyType) {
            uniqueCandies.add(candy);
        }

        // Return the minimum of unique candy types or the maximum number of candies Alice can eat
        return Math.min(uniqueCandies.size(), maxCandies);
    }
}
