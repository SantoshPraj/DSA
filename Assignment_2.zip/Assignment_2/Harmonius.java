import java.util.Arrays;

public class Harmonius {
    public static void main(String[] args) {
        int[] nums = {1, 3, 2, 2, 5, 2, 3, 7};
        int maxLength = findLHS(nums);

        // Print the length of the longest harmonious subsequence
        System.out.println(maxLength);
    }

    public static int findLHS(int[] nums) {
        Arrays.sort(nums);
        int maxLength = 0;

        int i = 0;
        int j = 0;

        while (j < nums.length) {
            if (nums[j] - nums[i] == 1) {
                maxLength = Math.max(maxLength, j - i + 1);
                j++;
            } else if (nums[j] - nums[i] > 1) {
                i++;
            } else {
                j++;
            }
        }

        return maxLength;
    }
}
