import java.util.Arrays;

public class Score {
    public static void main(String[] args) {
        int[] nums = {1};
        int k = 0;
        int minScore = minimumScore(nums, k);

        // Print the minimum score of nums
        System.out.println(minScore);
    }

    public static int minimumScore(int[] nums, int k) {
        Arrays.sort(nums); // Sort the array

        int n = nums.length;
        int minScore = nums[n - 1] - nums[0]; // Initialize the minimum score with the difference between maximum and minimum elements

        for (int i = 0; i < n - 1; i++) {
            int maxVal = Math.max(nums[i] + k, nums[n - 1] - k); // Try increasing the minimum element or decreasing the maximum element
            int minVal = Math.min(nums[i + 1] - k, nums[0] + k); // Try decreasing the next element or increasing the minimum element
            minScore = Math.min(minScore, maxVal - minVal); // Update the minimum score
        }

        return minScore;
    }
}
