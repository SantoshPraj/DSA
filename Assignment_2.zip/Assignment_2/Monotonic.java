public class Monotonic {
    public static void main(String[] args) {
        int[] nums = {1, 2, 2, 3};
        boolean isMonotonic = isMonotonic(nums);

        // Print whether the array is monotonic or not
        System.out.println(isMonotonic);
    }

    public static boolean isMonotonic(int[] nums) {
        int n = nums.length;
        boolean increasing = true;
        boolean decreasing = true;

        for (int i = 1; i < n; i++) {
            if (nums[i] < nums[i - 1]) {
                increasing = false; // Array is not monotone increasing
            }
            if (nums[i] > nums[i - 1]) {
                decreasing = false; // Array is not monotone decreasing
            }
        }

        return increasing || decreasing;
    }
}
