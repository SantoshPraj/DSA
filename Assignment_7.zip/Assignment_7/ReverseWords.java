public class ReverseWords {
    public static String reverseWords(String s) {
        String[] words = s.split("\\s+");

        for (int i = 0; i < words.length; i++) {
            char[] wordChars = words[i].toCharArray();
            reverseArray(wordChars);
            words[i] = new String(wordChars);
        }

        return String.join(" ", words);
    }

    private static void reverseArray(char[] arr) {
        int left = 0;
        int right = arr.length - 1;

        while (left < right) {
            char temp = arr[left];
            arr[left] = arr[right];
            arr[right] = temp;
            left++;
            right--;
        }
    }

    public static void main(String[] args) {
        String s = "Let's take LeetCode contest";
        System.out.println(reverseWords(s));  // Output: "s'teL ekat edoCteeL tsetnoc"
    }
}
