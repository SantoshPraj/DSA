public class StrobogrammaticNumber {
    public static boolean isStrobogrammatic(String num) {
        StringBuilder rotatedNum = new StringBuilder();

        for (int i = num.length() - 1; i >= 0; i--) {
            char digit = num.charAt(i);
            char rotatedDigit = rotateDigit(digit);
            if (rotatedDigit == '#')
                return false;
            rotatedNum.append(rotatedDigit);
        }

        return num.equals(rotatedNum.toString());
    }

    private static char rotateDigit(char digit) {
        switch (digit) {
            case '0':
                return '0';
            case '1':
                return '1';
            case '6':
                return '9';
            case '8':
                return '8';
            case '9':
                return '6';
            default:
                return '#';  // Not a valid digit for rotation
        }
    }

    public static void main(String[] args) {
        String num = "69";
        System.out.println(isStrobogrammatic(num));  // Output: true
    }
}
