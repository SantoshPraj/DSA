import java.util.Stack;

public class PostfixEvaluation {
    public static int evaluatePostfixExpression(String expression) {
        Stack<Integer> stack = new Stack<>();

        // Iterate through each character in the expression
        for (int i = 0; i < expression.length(); i++) {
            char c = expression.charAt(i);

            // If the character is a digit, push it onto the stack
            if (Character.isDigit(c)) {
                stack.push(c - '0');
            } else {
                // If the character is an operator, pop two operands from the stack
                int operand2 = stack.pop();
                int operand1 = stack.pop();

                // Perform the corresponding operation based on the operator
                switch (c) {
                    case '+':
                        stack.push(operand1 + operand2);
                        break;
                    case '-':
                        stack.push(operand1 - operand2);
                        break;
                    case '*':
                        stack.push(operand1 * operand2);
                        break;
                    case '/':
                        stack.push(operand1 / operand2);
                        break;
                }
            }
        }

        // The final result is the top element of the stack
        return stack.pop();
    }

    public static void main(String[] args) {
        String expression = "231*+9-";
        int result = evaluatePostfixExpression(expression);
        System.out.println("Postfix Expression: " + expression);
        System.out.println("Result: " + result);
    }
}
