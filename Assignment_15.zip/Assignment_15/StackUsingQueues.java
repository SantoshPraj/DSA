import java.util.LinkedList;
import java.util.Queue;

public class StackUsingQueues {
    Queue<Integer> q1 = new LinkedList<>();
    Queue<Integer> q2 = new LinkedList<>();

    // Function to push an element into the stack
    void push(int x) {
        // Move all elements from q1 to q2
        while (!q1.isEmpty()) {
            q2.add(q1.poll());
        }

        // Add the new element to q1
        q1.add(x);

        // Move all elements back to q1 from q2
        while (!q2.isEmpty()) {
            q1.add(q2.poll());
        }
    }

    // Function to remove the top element from the stack
    int pop() {
        // If the stack is empty
        if (q1.isEmpty()) {
            System.out.println("Stack is empty");
            return -1;
        }

        // Return the front element of q1 (which is the top element of the stack)
        return q1.poll();
    }

    public static void main(String[] args) {
        StackUsingQueues stack = new StackUsingQueues();

        stack.push(2);
        stack.push(3);
        System.out.println(stack.pop());
        stack.push(4);
        System.out.println(stack.pop());
    }
}
