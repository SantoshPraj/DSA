import java.util.Arrays;
import java.util.Stack;

public class NearestSmallerElement {
    public static int[] findNearestSmallerElements(int[] arr) {
        int n = arr.length;
        int[] result = new int[n];
        Stack<Integer> stack = new Stack<>();

        // Iterate from left to right
        for (int i = 0; i < n; i++) {
            // Pop elements greater than or equal to the current element
            while (!stack.isEmpty() && stack.peek() >= arr[i]) {
                stack.pop();
            }

            // If stack is empty, there is no smaller element
            if (stack.isEmpty()) {
                result[i] = -1;
            } else {
                result[i] = stack.peek();
            }

            // Push the current element to the stack
            stack.push(arr[i]);
        }

        return result;
    }

    public static void main(String[] args) {
        int[] arr = {1, 6, 2};
        int[] nearestSmallerElements = findNearestSmallerElements(arr);
        System.out.println(Arrays.toString(nearestSmallerElements));
    }
}
