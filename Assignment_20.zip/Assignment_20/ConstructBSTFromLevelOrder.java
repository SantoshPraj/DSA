class TreeNode {
    int val;
    TreeNode left;
    TreeNode right;

    TreeNode(int val) {
        this.val = val;
    }
}

public class ConstructBSTFromLevelOrder {
    public TreeNode constructBST(int[] levelOrder) {
        if (levelOrder == null || levelOrder.length == 0) {
            return null;
        }

        TreeNode root = new TreeNode(levelOrder[0]);

        for (int i = 1; i < levelOrder.length; i++) {
            constructBSTHelper(root, levelOrder[i]);
        }

        return root;
    }

    private void constructBSTHelper(TreeNode node, int value) {
        if (value < node.val) {
            if (node.left == null) {
                node.left = new TreeNode(value);
            } else {
                constructBSTHelper(node.left, value);
            }
        } else {
            if (node.right == null) {
                node.right = new TreeNode(value);
            } else {
                constructBSTHelper(node.right, value);
            }
        }
    }

    public void printBST(TreeNode root) {
        if (root == null) {
            return;
        }

        System.out.println(root.val);
        printBST(root.left);
        printBST(root.right);
    }

    public static void main(String[] args) {
        ConstructBSTFromLevelOrder bstConstructor = new ConstructBSTFromLevelOrder();
        int[] levelOrder = {7, 4, 12, 3, 6, 8, 1, 5, 10};
        TreeNode root = bstConstructor.constructBST(levelOrder);
        bstConstructor.printBST(root);
    }
}
