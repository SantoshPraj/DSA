class TreeNode {
    int val;
    TreeNode left;
    TreeNode right;

    TreeNode(int val) {
        this.val = val;
    }
}

class Result {
    int maxSum;

    Result() {
        this.maxSum = Integer.MIN_VALUE;
    }
}

public class MaximumSubtreeSum {
    public int findMaxSubtreeSum(TreeNode root) {
        Result result = new Result();
        findMaxSubtreeSumHelper(root, result);
        return result.maxSum;
    }

    private int findMaxSubtreeSumHelper(TreeNode node, Result result) {
        if (node == null) {
            return 0;
        }

        int leftSum = findMaxSubtreeSumHelper(node.left, result);
        int rightSum = findMaxSubtreeSumHelper(node.right, result);

        int currentSum = node.val + leftSum + rightSum;
        result.maxSum = Math.max(result.maxSum, currentSum);

        return currentSum;
    }

    public static void main(String[] args) {
        TreeNode root = new TreeNode(1);
        root.left = new TreeNode(2);
        root.right = new TreeNode(3);
        root.left.left = new TreeNode(4);
        root.left.right = new TreeNode(5);
        root.right.left = new TreeNode(6);
        root.right.right = new TreeNode(7);

        MaximumSubtreeSum subtreeSum = new MaximumSubtreeSum();
        int maxSum = subtreeSum.findMaxSubtreeSum(root);
        System.out.println("Maximum Subtree Sum: " + maxSum);
    }
}
