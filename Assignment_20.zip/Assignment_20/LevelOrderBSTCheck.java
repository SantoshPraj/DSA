public class LevelOrderBSTCheck {
    public boolean isLevelOrderBST(int[] levelOrder) {
        if (levelOrder == null || levelOrder.length == 0) {
            return true;
        }

        return isLevelOrderBSTHelper(levelOrder, 0, levelOrder.length - 1);
    }

    private boolean isLevelOrderBSTHelper(int[] levelOrder, int start, int end) {
        if (start > end) {
            return true;
        }

        int rootValue = levelOrder[start];
        int i;

        // Find the index of the first element greater than the root value
        for (i = start + 1; i <= end; i++) {
            if (levelOrder[i] > rootValue) {
                break;
            }
        }

        // Check if all elements after the first greater element are greater than rootValue
        for (int j = i; j <= end; j++) {
            if (levelOrder[j] < rootValue) {
                return false;
            }
        }

        // Recursively check for left and right subtrees
        boolean leftSubtree = isLevelOrderBSTHelper(levelOrder, start + 1, i - 1);
        boolean rightSubtree = isLevelOrderBSTHelper(levelOrder, i, end);

        return leftSubtree && rightSubtree;
    }

    public static void main(String[] args) {
        LevelOrderBSTCheck bstChecker = new LevelOrderBSTCheck();
        int[] levelOrder1 = {7, 4, 12, 3, 6, 8, 1, 5, 10};
        boolean isBST1 = bstChecker.isLevelOrderBST(levelOrder1);
        System.out.println("Is Level Order BST: " + isBST1);

        int[] levelOrder2 = {11, 6, 13, 5, 12, 10};
        boolean isBST2 = bstChecker.isLevelOrderBST(levelOrder2);
        System.out.println("Is Level Order BST: " + isBST2);
    }
}
