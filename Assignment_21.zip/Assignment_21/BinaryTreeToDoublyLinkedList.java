class TreeNode {
    int val;
    TreeNode left;
    TreeNode right;

    TreeNode(int val) {
        this.val = val;
    }
}

class DoublyLinkedListNode {
    int val;
    DoublyLinkedListNode prev;
    DoublyLinkedListNode next;

    DoublyLinkedListNode(int val) {
        this.val = val;
    }
}

public class BinaryTreeToDoublyLinkedList {
    private DoublyLinkedListNode head;
    private DoublyLinkedListNode prev;

    public DoublyLinkedListNode convertToDoublyLinkedList(TreeNode root) {
        head = null;
        prev = null;
        inOrderTraversal(root);
        return head;
    }

    private void inOrderTraversal(TreeNode node) {
        if (node == null) {
            return;
        }

        inOrderTraversal(node.left);

        DoublyLinkedListNode curr = new DoublyLinkedListNode(node.val);

        if (head == null) {
            head = curr;
        } else {
            prev.next = curr;
            curr.prev = prev;
        }

        prev = curr;

        inOrderTraversal(node.right);
    }

    public void printDoublyLinkedList(DoublyLinkedListNode node) {
        while (node != null) {
            System.out.print(node.val + " ");
            node = node.next;
        }
        System.out.println();
    }

    public static void main(String[] args) {
        BinaryTreeToDoublyLinkedList converter = new BinaryTreeToDoublyLinkedList();

        TreeNode root = new TreeNode(10);
        root.left = new TreeNode(5);
        root.right = new TreeNode(20);
        root.right.left = new TreeNode(30);
        root.right.right = new TreeNode(35);

        DoublyLinkedListNode doublyLinkedList = converter.convertToDoublyLinkedList(root);
        converter.printDoublyLinkedList(doublyLinkedList);
    }
}
