class TreeNode {
    int val;
    TreeNode left;
    TreeNode right;
    TreeNode next;

    TreeNode(int val) {
        this.val = val;
    }
}

public class ConnectNodesAtSameLevel {
    public void connect(TreeNode root) {
        if (root == null) {
            return;
        }

        Queue<TreeNode> queue = new LinkedList<>();
        queue.offer(root);

        while (!queue.isEmpty()) {
            int size = queue.size();
            TreeNode prev = null;

            for (int i = 0; i < size; i++) {
                TreeNode curr = queue.poll();

                if (prev != null) {
                    prev.next = curr;
                }

                prev = curr;

                if (curr.left != null) {
                    queue.offer(curr.left);
                }
                if (curr.right != null) {
                    queue.offer(curr.right);
                }
            }
        }
    }

    public void printConnectedNodes(TreeNode root) {
        while (root != null) {
            TreeNode curr = root;
            while (curr != null) {
                System.out.print(curr.val + " → ");
                curr = curr.next;
            }
            System.out.println("-1");
            root = root.left;
        }
    }

    public static void main(String[] args) {
        ConnectNodesAtSameLevel connector = new ConnectNodesAtSameLevel();

        TreeNode root = new TreeNode(1);
        root.left = new TreeNode(2);
        root.right = new TreeNode(3);
        root.left.left = new TreeNode(4);
        root.left.right = new TreeNode(5);
        root.right.left = new TreeNode(6);
        root.right.right = new TreeNode(7);

        connector.connect(root);
        connector.printConnectedNodes(root);
    }
}
