class TreeNode {
    int val;
    TreeNode left;
    TreeNode right;

    TreeNode(int val) {
        this.val = val;
    }
}

public class DistanceBetweenNodesBST {
    public int findDistance(TreeNode root, int node1, int node2) {
        TreeNode lcaNode = findLCA(root, node1, node2);
        int dist1 = findDistanceFromNode(lcaNode, node1, 0);
        int dist2 = findDistanceFromNode(lcaNode, node2, 0);
        return dist1 + dist2;
    }

    private TreeNode findLCA(TreeNode node, int node1, int node2) {
        if (node == null) {
            return null;
        }

        if (node.val > node1 && node.val > node2) {
            return findLCA(node.left, node1, node2);
        }

        if (node.val < node1 && node.val < node2) {
            return findLCA(node.right, node1, node2);
        }

        return node;
    }

    private int findDistanceFromNode(TreeNode node, int target, int distance) {
        if (node == null) {
            return -1;
        }

        if (node.val == target) {
            return distance;
        }

        int leftDist = findDistanceFromNode(node.left, target, distance + 1);
        int rightDist = findDistanceFromNode(node.right, target, distance + 1);

        if (leftDist != -1) {
            return leftDist;
        }

        return rightDist;
    }

    public static void main(String[] args) {
        DistanceBetweenNodesBST bst = new DistanceBetweenNodesBST();

        // Test case 1
        TreeNode root1 = new TreeNode(8);
        root1.left = new TreeNode(3);
        root1.left.left = new TreeNode(1);
        root1.left.right = new TreeNode(6);
        root1.left.right.left = new TreeNode(4);
        root1.left.right.right = new TreeNode(7);
        root1.right = new TreeNode(10);
        root1.right.right = new TreeNode(14);
        root1.right.right.left = new TreeNode(13);

        int distance1 = bst.findDistance(root1, 6, 14);
        System.out.println("Distance between 6 and 14: " + distance1);

        // Test case 2
        TreeNode root2 = new TreeNode(8);
        root2.left = new TreeNode(3);
        root2.left.left = new TreeNode(1);
        root2.left.right = new TreeNode(6);
        root2.left.right.left = new TreeNode(4);
        root2.left.right.right = new TreeNode(7);
        root2.right = new TreeNode(10);
        root2.right.right = new TreeNode(14);
        root2.right.right.left = new TreeNode(13);

        int distance2 = bst.findDistance(root2, 3, 4);
        System.out.println("Distance between 3 and 4: " + distance2);
    }
}
