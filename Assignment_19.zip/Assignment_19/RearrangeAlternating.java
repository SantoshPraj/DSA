public class RearrangeAlternating {
    public void rearrangeArray(int[] nums) {
        int n = nums.length;
        int positiveIndex = 0;
        int negativeIndex = 0;

        while (positiveIndex < n && negativeIndex < n) {
            while (positiveIndex < n && nums[positiveIndex] >= 0) {
                positiveIndex++;
            }

            while (negativeIndex < n && nums[negativeIndex] < 0) {
                negativeIndex++;
            }

            if (positiveIndex < n && negativeIndex < n && positiveIndex < negativeIndex) {
                rotate(nums, positiveIndex, negativeIndex);
                positiveIndex += 2;
                negativeIndex++;
            } else {
                break;
            }
        }
    }

    private void rotate(int[] nums, int start, int end) {
        int temp = nums[end];

        for (int i = end; i > start; i--) {
            nums[i] = nums[i - 1];
        }

        nums[start] = temp;
    }

    public static void main(String[] args) {
        RearrangeAlternating rearranger = new RearrangeAlternating();
        int[] nums = {1, 2, 3, -4, -1, 4};
        rearranger.rearrangeArray(nums);

        // Print the rearranged array
        for (int num : nums) {
            System.out.print(num + " ");
        }
    }
}
