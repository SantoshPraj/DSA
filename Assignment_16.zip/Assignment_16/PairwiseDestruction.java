import java.util.Stack;

public class PairwiseDestruction {
    public static int countWordsLeft(String[] words) {
        Stack<String> stack = new Stack<>();

        for (String word : words) {
            if (!stack.isEmpty() && stack.peek().equals(word)) {
                stack.pop(); // Destroy the pair
            } else {
                stack.push(word); // Add the word to the stack
            }
        }

        return stack.size();
    }

    public static void main(String[] args) {
        String[] words1 = {"ab", "aa", "aa", "bcd", "ab"};
        int count1 = countWordsLeft(words1);
        System.out.println("Words left after pairwise destruction: " + count1);

        String[] words2 = {"tom", "jerry", "jerry", "tom"};
        int count2 = countWordsLeft(words2);
        System.out.println("Words left after pairwise destruction: " + count2);
    }
}
