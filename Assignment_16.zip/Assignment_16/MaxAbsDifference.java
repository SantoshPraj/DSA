import java.util.Stack;

public class MaxAbsDifference {
    public static int maxAbsDifference(int[] arr) {
        int n = arr.length;
        int[] leftSmaller = new int[n];
        int[] rightSmaller = new int[n];

        // Find the nearest smaller element on the left side
        Stack<Integer> stack = new Stack<>();
        for (int i = 0; i < n; i++) {
            while (!stack.isEmpty() && stack.peek() >= arr[i]) {
                stack.pop();
            }
            leftSmaller[i] = stack.isEmpty() ? 0 : stack.peek();
            stack.push(arr[i]);
        }

        // Clear the stack for finding the nearest smaller element on the right side
        stack.clear();

        // Find the nearest smaller element on the right side
        for (int i = n - 1; i >= 0; i--) {
            while (!stack.isEmpty() && stack.peek() >= arr[i]) {
                stack.pop();
            }
            rightSmaller[i] = stack.isEmpty() ? 0 : stack.peek();
            stack.push(arr[i]);
        }

        // Find the maximum absolute difference between leftSmaller[i] and rightSmaller[i]
        int maxDiff = 0;
        for (int i = 0; i < n; i++) {
            maxDiff = Math.max(maxDiff, Math.abs(leftSmaller[i] - rightSmaller[i]));
        }

        return maxDiff;
    }

    public static void main(String[] args) {
        int[] arr1 = {2, 1, 8};
        int maxDiff1 = maxAbsDifference(arr1);
        System.out.println("Maximum absolute difference: " + maxDiff1);

        int[] arr2 = {2, 4, 8, 7, 7, 9, 3};
        int maxDiff2 = maxAbsDifference(arr2);
        System.out.println("Maximum absolute difference: " + maxDiff2);

        int[] arr3 = {5, 1, 9, 2, 5, 1, 7};
        int maxDiff3 = maxAbsDifference(arr3);
        System.out.println("Maximum absolute difference: " + maxDiff3);
    }
}
