import java.util.Stack;

public class ReverseNumber {
    public static int reverse(int num) {
        String numString = Integer.toString(num);
        Stack<Character> stack = new Stack<>();

        for (char ch : numString.toCharArray()) {
            stack.push(ch);
        }

        StringBuilder reversedString = new StringBuilder();

        while (!stack.isEmpty()) {
            reversedString.append(stack.pop());
        }

        return Integer.parseInt(reversedString.toString());
    }

    public static void main(String[] args) {
        int num1 = 365;
        int reversedNum1 = reverse(num1);
        System.out.println("Reversed number of " + num1 + " is " + reversedNum1);

        int num2 = 6899;
        int reversedNum2 = reverse(num2);
        System.out.println("Reversed number of " + num2 + " is " + reversedNum2);
    }
}
