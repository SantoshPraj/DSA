import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class DistinctIntegers {
    public static List<List<Integer>> findDistinctIntegers(int[] nums1, int[] nums2) {
        List<Integer> distinctInNums1 = new ArrayList<>();
        List<Integer> distinctInNums2 = new ArrayList<>();

        Set<Integer> nums1Set = new HashSet<>();
        for (int num : nums1) {
            nums1Set.add(num);
        }

        Set<Integer> nums2Set = new HashSet<>();
        for (int num : nums2) {
            nums2Set.add(num);
        }

        for (int num : nums1) {
            if (!nums2Set.contains(num)) {
                distinctInNums1.add(num);
            }
        }

        for (int num : nums2) {
            if (!nums1Set.contains(num)) {
                distinctInNums2.add(num);
            }
        }

        List<List<Integer>> result = new ArrayList<>();
        result.add(distinctInNums1);
        result.add(distinctInNums2);

        return result;
    }

    public static void main(String[] args) {
        int[] nums1 = {1, 2, 3};
        int[] nums2 = {2, 4, 6};

        List<List<Integer>> distinctIntegers = findDistinctIntegers(nums1, nums2);

        System.out.println("Distinct integers in nums1: " + distinctIntegers.get(0));
        System.out.println("Distinct integers in nums2: " + distinctIntegers.get(1));
    }
}
