import java.util.Stack;

public class Pattern132 {
    public boolean find132pattern(int[] nums) {
        int n = nums.length;
        Stack<Integer> stack = new Stack<>();
        int potentialRight = Integer.MIN_VALUE;

        for (int i = n - 1; i >= 0; i--) {
            if (nums[i] < potentialRight) {
                return true; // Pattern found
            }

            while (!stack.isEmpty() && nums[i] > stack.peek()) {
                potentialRight = stack.pop();
            }

            stack.push(nums[i]);
        }

        return false; // Pattern not found
    }

    public static void main(String[] args) {
        Pattern132 pattern = new Pattern132();
        int[] nums = {1, 2, 3, 4};
        boolean containsPattern = pattern.find132pattern(nums);
        System.out.println("Contains 132 pattern: " + containsPattern);
    }
}
