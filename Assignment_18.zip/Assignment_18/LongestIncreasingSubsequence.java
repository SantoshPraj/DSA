public class LongestIncreasingSubsequence {
    public int lengthOfLIS(int[] nums) {
        int n = nums.length;
        int[] dp = new int[n]; // dp[i] represents the length of the LIS ending at index i
        Arrays.fill(dp, 1); // Initialize all elements with 1 (minimum possible length)

        for (int i = 1; i < n; i++) {
            for (int j = 0; j < i; j++) {
                if (nums[i] > nums[j]) {
                    // If nums[i] is greater than nums[j], we can extend the LIS ending at index j
                    dp[i] = Math.max(dp[i], dp[j] + 1);
                }
            }
        }

        // Find the maximum value in the dp array
        int maxLen = 0;
        for (int len : dp) {
            maxLen = Math.max(maxLen, len);
        }

        return maxLen;
    }

    public static void main(String[] args) {
        LongestIncreasingSubsequence lis = new LongestIncreasingSubsequence();
        int[] nums = {10, 9, 2, 5, 3, 7, 101, 18};
        int maxLength = lis.lengthOfLIS(nums);
        System.out.println("Length of the longest increasing subsequence: " + maxLength);
    }
}
