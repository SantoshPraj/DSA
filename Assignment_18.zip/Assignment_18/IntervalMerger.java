import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class IntervalMerger {
    public int[][] mergeIntervals(int[][] intervals) {
        // Sort intervals based on the start time
        Arrays.sort(intervals, (a, b) -> Integer.compare(a[0], b[0]));

        List<int[]> mergedIntervals = new ArrayList<>();
        int[] currentInterval = intervals[0];

        for (int i = 1; i < intervals.length; i++) {
            int[] interval = intervals[i];
            if (interval[0] <= currentInterval[1]) {
                // Overlapping intervals, update the end time
                currentInterval[1] = Math.max(currentInterval[1], interval[1]);
            } else {
                // Non-overlapping interval, add currentInterval to the result and update currentInterval
                mergedIntervals.add(currentInterval);
                currentInterval = interval;
            }
        }

        // Add the last interval to the result
        mergedIntervals.add(currentInterval);

        // Convert List to array
        int[][] mergedArray = new int[mergedIntervals.size()][2];
        for (int i = 0; i < mergedIntervals.size(); i++) {
            mergedArray[i] = mergedIntervals.get(i);
        }

        return mergedArray;
    }

    public static void main(String[] args) {
        IntervalMerger merger = new IntervalMerger();
        int[][] intervals = {{1, 3}, {2, 6}, {8, 10}, {15, 18}};
        int[][] mergedIntervals = merger.mergeIntervals(intervals);

        // Print the merged intervals
        for (int[] interval : mergedIntervals) {
            System.out.println(Arrays.toString(interval));
        }
    }
}
