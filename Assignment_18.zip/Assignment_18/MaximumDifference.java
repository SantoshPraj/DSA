import java.util.Arrays;

public class MaximumDifference {
    public int maximumGap(int[] nums) {
        if (nums.length < 2) {
            return 0;
        }

        // Find the maximum element in the array
        int max = Arrays.stream(nums).max().getAsInt();

        // Perform radix sort
        int exp = 1;
        int[] sorted = new int[nums.length];

        while (max / exp > 0) {
            int[] count = new int[10];

            // Counting sort based on the current digit
            for (int num : nums) {
                int digit = (num / exp) % 10;
                count[digit]++;
            }

            // Calculate the cumulative count
            for (int i = 1; i < 10; i++) {
                count[i] += count[i - 1];
            }

            // Build the sorted array
            for (int i = nums.length - 1; i >= 0; i--) {
                int digit = (nums[i] / exp) % 10;
                sorted[count[digit] - 1] = nums[i];
                count[digit]--;
            }

            // Update the original array
            System.arraycopy(sorted, 0, nums, 0, nums.length);

            // Move to the next digit
            exp *= 10;
        }

        // Calculate the maximum difference
        int maxDiff = 0;
        for (int i = 1; i < nums.length; i++) {
            maxDiff = Math.max(maxDiff, nums[i] - nums[i - 1]);
        }

        return maxDiff;
    }

    public static void main(String[] args) {
        MaximumDifference maxDiff = new MaximumDifference();
        int[] nums = {3, 6, 9, 1};
        int result = maxDiff.maximumGap(nums);
        System.out.println("Maximum difference: " + result);
    }
}
