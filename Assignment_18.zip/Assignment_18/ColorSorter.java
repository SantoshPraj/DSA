public class ColorSorter {
    public void sortColors(int[] nums) {
        int low = 0;           // Pointer for 0's
        int mid = 0;           // Pointer for 1's
        int high = nums.length - 1;  // Pointer for 2's

        while (mid <= high) {
            if (nums[mid] == 0) {
                // Swap current element with the element at the low pointer
                swap(nums, low, mid);
                low++;
                mid++;
            } else if (nums[mid] == 1) {
                // Move to the next element
                mid++;
            } else if (nums[mid] == 2) {
                // Swap current element with the element at the high pointer
                swap(nums, mid, high);
                high--;
            }
        }
    }

    private void swap(int[] nums, int i, int j) {
        int temp = nums[i];
        nums[i] = nums[j];
        nums[j] = temp;
    }

    public static void main(String[] args) {
        ColorSorter sorter = new ColorSorter();
        int[] nums = {2, 0, 2, 1, 1, 0};
        sorter.sortColors(nums);

        // Print the sorted colors
        for (int num : nums) {
            System.out.print(num + " ");
        }
    }
}
