import java.util.Arrays;

public class MinArrowsToBurstBalloons {
    public int findMinArrowShots(int[][] points) {
        if (points.length == 0) {
            return 0;
        }

        // Sort the points based on the end position in ascending order
        Arrays.sort(points, (a, b) -> Integer.compare(a[1], b[1]));

        int arrows = 1; // First balloon always needs an arrow
        int prevEnd = points[0][1];

        for (int i = 1; i < points.length; i++) {
            if (points[i][0] > prevEnd) {
                // Balloon is not covered by the previous arrow, so a new arrow is needed
                arrows++;
                prevEnd = points[i][1];
            }
        }

        return arrows;
    }

    public static void main(String[] args) {
        MinArrowsToBurstBalloons minArrows = new MinArrowsToBurstBalloons();
        int[][] points = {{10, 16}, {2, 8}, {1, 6}, {7, 12}};
        int minArrowsNeeded = minArrows.findMinArrowShots(points);
        System.out.println("Minimum number of arrows needed: " + minArrowsNeeded);
    }
}
