import java.util.*;

class TreeNode {
    int val;
    TreeNode left;
    TreeNode right;

    TreeNode(int val) {
        this.val = val;
    }
}

class Pair {
    TreeNode node;
    int hd;

    Pair(TreeNode node, int hd) {
        this.node = node;
        this.hd = hd;
    }
}

public class BottomViewBinaryTree {
    public void printBottomView(TreeNode root) {
        if (root == null) {
            return;
        }

        Map<Integer, Integer> map = new TreeMap<>();
        Queue<Pair> queue = new LinkedList<>();
        queue.offer(new Pair(root, 0));

        while (!queue.isEmpty()) {
            Pair pair = queue.poll();
            TreeNode curr = pair.node;
            int hd = pair.hd;

            // Update the map with the current node at its horizontal distance
            map.put(hd, curr.val);

            if (curr.left != null) {
                queue.offer(new Pair(curr.left, hd - 1));
            }
            if (curr.right != null) {
                queue.offer(new Pair(curr.right, hd + 1));
            }
        }

        // Print the nodes from the map in order of their horizontal distance
        for (int val : map.values()) {
            System.out.print(val + " ");
        }
    }

    public static void main(String[] args) {
        BottomViewBinaryTree treeViewer = new BottomViewBinaryTree();

        TreeNode root = new TreeNode(20);
        root.left = new TreeNode(8);
        root.right = new TreeNode(22);
        root.left.left = new TreeNode(5);
        root.left.right = new TreeNode(3);
        root.right.right = new TreeNode(25);
        root.left.right.left = new TreeNode(10);
        root.left.right.right = new TreeNode(14);

        treeViewer.printBottomView(root);
    }
}
