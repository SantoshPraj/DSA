class Node {
    char data;
    Node left;
    Node right;

    Node(char data) {
        this.data = data;
        this.left = null;
        this.right = null;
    }
}

public class PreorderDepth {
    private static int index;

    public int calculateDepth(String preorder) {
        index = 0;
        return calculateDepthHelper(preorder);
    }

    private int calculateDepthHelper(String preorder) {
        if (index == preorder.length()) {
            return 0;
        }

        char current = preorder.charAt(index++);
        if (current == 'l') {
            return 0;
        } else if (current == 'n') {
            int leftDepth = calculateDepthHelper(preorder);
            int rightDepth = calculateDepthHelper(preorder);
            return Math.max(leftDepth, rightDepth) + 1;
        }

        return 0;
    }

    public static void main(String[] args) {
        PreorderDepth depthCalculator = new PreorderDepth();
        String preorder = "nlnll";

        int depth = depthCalculator.calculateDepth(preorder);
        System.out.println("Depth of the binary tree: " + depth);
    }
}
